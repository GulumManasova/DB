from heroes import Warrior, Mage
from monster import Goblin
from items import HealthPotion, Sword


def battle():
    hero1 = Warrior("Aragorn")
    hero2 = Mage("Gandalf")
    monster = Goblin()

    # Items
    hero1.add_item(Sword())
    hero2.add_item(HealthPotion())

    print(hero1)
    print(hero2)
    print(monster)

    print("\n--- Battle Start ---\n")

    hero1.use_item("Sword")
    hero2.use_item("Health Potion")

    turn = 1
    while monster.is_alive() and (hero1.is_alive() or hero2.is_alive()):
        print(f"\n--- Turn {turn} ---")

        if hero1.is_alive():
            hero1.attack(monster)

        if monster.is_alive() and hero2.is_alive():
            hero2.attack(monster)

        if monster.is_alive():
            target = hero1 if hero1.is_alive() else hero2
            monster.attack(target)

        turn += 1

    print("\n--- Battle End ---")

    if monster.is_alive():
        print("Monster wins!")
    else:
        print("Heroes win!")


if __name__ == "__main__":
    battle()
