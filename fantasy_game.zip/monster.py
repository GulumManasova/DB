import random
from character import Character

class Goblin(Character):
    def __init__(self, name="Goblin"):
        super().__init__(name, health=60, attack_power=12)

    def take_damage(self, amount):
        if random.random() < 0.3:
            print(f"{self.name} dodged the attack! 🏃")
        else:
            super().take_damage(amount)
