import random
from character import Character

class Warrior(Character):
    def __init__(self, name):
        super().__init__(name, health=120, attack_power=15)
        self.armor = 3

    def take_damage(self, amount):
        reduced = max(0, amount - self.armor)
        print(f"{self.name}'s armor reduces damage!")
        super().take_damage(reduced)


class Mage(Character):
    def __init__(self, name):
        super().__init__(name, health=80, attack_power=10)
        self.mana = 50

    def attack(self, target):
        if self.mana >= 10:
            damage = self.attack_power * 2
            self.mana -= 10
            print(f"{self.name} casts a spell! 🔥 ({damage} dmg)")
            target.take_damage(damage)
        else:
            print(f"{self.name} has no mana, uses weak attack")
            super().attack(target)
