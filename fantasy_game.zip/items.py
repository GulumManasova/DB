class Item:
    def __init__(self, name):
        self.name = name

    def use(self, target):
        pass


class HealthPotion(Item):
    def __init__(self):
        super().__init__("Health Potion")
        self.heal_amount = 30

    def use(self, target):
        target._health += self.heal_amount
        print(f"{target.name} heals {self.heal_amount} HP ❤️")


class Sword(Item):
    def __init__(self):
        super().__init__("Sword")
        self.bonus = 5

    def use(self, target):
        target.attack_power += self.bonus
        print(f"{target.name}'s attack increased by {self.bonus} ⚔️")
