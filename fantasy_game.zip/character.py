class Character:
    def __init__(self, name, health, attack_power):
        self.name = name
        self._health = health
        self.attack_power = attack_power
        self.inventory = []

    def attack(self, target):
        print(f"{self.name} attacks {target.name} for {self.attack_power} damage")
        target.take_damage(self.attack_power)

    def take_damage(self, amount):
        self._health = max(0, self._health - amount)
        print(f"{self.name} takes {amount} damage. HP: {self._health}")

    def is_alive(self):
        return self._health > 0

    def add_item(self, item):
        self.inventory.append(item)

    def use_item(self, item_name):
        for item in self.inventory:
            if item.name == item_name:
                item.use(self)
                self.inventory.remove(item)
                return
        print(f"{item_name} not found in inventory")

    def __str__(self):
        return f"{self.name} (HP: {self._health}, ATK: {self.attack_power})"
